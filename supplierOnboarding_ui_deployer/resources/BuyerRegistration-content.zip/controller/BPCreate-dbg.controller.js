sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "ns/BuyerRegistration/util/formatter",
    "sap/ui/model/Filter"
],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, formatter, Filter) {
        "use strict";
        var oView, oCont;
        return Controller.extend("ns.BuyerRegistration.controller.BPCreate", {
            onInit: function () {
                oView = this.getView();
                oCont = this;
                var oHeader = [{
                    "Bukrs": "G01",
                    "Ekorg": "ACLARA PL",
                }, {
                    "Bukrs": "G02",
                    "Ekorg": "ACLARA PL1",
                }, {
                    "Bukrs": "G03",
                    "Ekorg": "ACLARA PL2",
                }, {
                    "Bukrs": "G04",
                    "Ekorg": "ACLARA PL3",
                }, {
                    "Bukrs": "G05",
                    "Ekorg": "ACLARA PL4",
                }, {
                    "Bukrs": "G06",
                    "Ekorg": "ACLARA PL5",
                }];
                var oHeaderJson = new sap.ui.model.json.JSONModel();
                oHeaderJson.setData(oHeader);
                oView.setModel(oHeaderJson, "oListModel");

                var oVendorList = [{
                    "VendorName": "William Incture PVT Ltd Banglore"
                },
                {
                    "VendorName": "William Corporations"
                }, {
                    "VendorName": "William Constructions"
                }
                ];
                var oVendorListJson = new sap.ui.model.json.JSONModel();
                oVendorListJson.setData(oVendorList);
                oView.setModel(oVendorListJson, "oVendorListModel");
                this.oSF = oView.byId("searchField");

                var oConfigModel = {
                    "BPCreate": true,
                    "BPExtend": false,
                    "BPCreateSel": false,
                    "BPExtendSel": false
                }

                var oConfigJson = new sap.ui.model.json.JSONModel();
                oConfigJson.setData(oConfigModel);
                oView.setModel(oConfigJson, "oConfigModel");

            },
            fnNavToBPCreate: function () {
                this.getOwnerComponent().getRouter().navTo("VendorRequest");
            },
            onSuggest: function (event) {
                var sValue = event.getParameter("suggestValue"),
                    aFilters = [];
                if (sValue) {
                    aFilters = [
                        new Filter([
                            new Filter("VendorName", function (sText) {
                                return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
                            }),
                        ], false)
                    ];
                }

                this.oSF.getBinding("suggestionItems").filter(aFilters);
                this.oSF.suggest();
            },
            onSearch: function (oEvent) {
                if (oEvent.getParameter("query")) {
                    oView.getModel("oConfigModel").getData().BPCreate = false;
                    oView.getModel("oConfigModel").getData().BPExtend = true;
                    oView.getModel("oConfigModel").refresh();
                } else {
                    oView.getModel("oConfigModel").getData().BPCreate = true;
                    oView.getModel("oConfigModel").getData().BPExtend = false;
                    oView.getModel("oConfigModel").refresh();
                }

            },
            fnChangeBPExists:function(){
                  oView.getModel("oConfigModel").getData().BPCreate = false;
                    oView.getModel("oConfigModel").getData().BPExtend = true;
                       oView.getModel("oConfigModel").getData().BPExtendSel = true;
                    oView.getModel("oConfigModel").refresh();
            },
            fnChangeBPCreate:function(){
                  oView.getModel("oConfigModel").getData().BPCreate = true;
                    oView.getModel("oConfigModel").getData().BPExtend = false;
                     oView.getModel("oConfigModel").getData().BPCreateSel = true;
                    
                    oView.getModel("oConfigModel").refresh();
            }
        });
    });
