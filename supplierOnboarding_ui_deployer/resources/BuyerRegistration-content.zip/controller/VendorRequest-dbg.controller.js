sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "ns/BuyerRegistration/util/formatter"
],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, formatter) {
        "use strict";

        return Controller.extend("ns.BuyerRegistration.controller.VendorRequest", {
            onInit: function () {

                var oHeader = [{
                    "RequestID": "VOR-000005",
                    "Erdat": "20-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862346",
                    "Status": "In Progress"
                }, {
                    "RequestID": "VOR-000004",
                    "Erdat": "15-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862341",
                    "Status": "In Progress"
                }, {
                    "RequestID": "VOR-000003",
                    "Erdat": "10-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862346",
                    "Status": "Completed"
                }, {
                    "RequestID": "VOR-000002",
                    "Erdat": "08-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862346",
                    "Status": "Completed"
                }, {
                    "RequestID": "VOR-000001",
                    "Erdat": "06-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862346",
                    "Status": "Error"
                }, {
                    "RequestID": "VOR-000001",
                    "Erdat": "06-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862346",
                    "Status": "Error"
                }, {
                    "RequestID": "VOR-000001",
                    "Erdat": "06-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862346",
                    "Status": "Error"
                }, {
                    "RequestID": "VOR-000001",
                    "Erdat": "06-01-2020",
                    "Ernam": "Eric Tran",
                    "SAPBPNumber": "BP32862346",
                    "Status": "Error"
                }];
                var oHeaderJson = new sap.ui.model.json.JSONModel();
                oHeaderJson.setData(oHeader);
                this.getView().setModel(oHeaderJson, "oListModel");

           

            },
            onAfterRendering: function () {
                debugger;
              
            },
            fnNavToBPCreate:function(){
               this.getOwnerComponent().getRouter().navTo("BPCreate");  
            }
        });
    });
