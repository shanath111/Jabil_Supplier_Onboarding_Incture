jQuery.sap.declare("ns.BuyerRegistration.util.formatter");
jQuery.sap.require("sap.ui.core.format.NumberFormat");

ns.BuyerRegistration.util.formatter = {

    fnStatusColour: function (vStatus) {
        var id = this.oParent.sId;
        var cid = this.oParent.oParent.oParent.sId;

        if (vStatus == "Completed") {
            return "Success";
        } else if (vStatus == "Error") {
            return "Error";
        } else {
            return "Warning";
        }

    },

   

};