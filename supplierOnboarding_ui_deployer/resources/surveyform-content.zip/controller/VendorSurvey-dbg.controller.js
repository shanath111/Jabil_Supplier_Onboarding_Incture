sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"com/jabil/surveyform/controller/BaseController",
        'sap/ui/model/json/JSONModel',
        'sap/m/MessageBox',
		'com/jabil/surveyform/formatter/formatter'

	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 * @param {typeof sap.ui.core.mvc.Controller} BaseController 
	 * @param {typeof sap.ui.model.json.JSONModel} formatter 
	 */
	// @ts-ignore
	/**
 * @param {typeof sap.ui.core.mvc.Controller} BaseController 
 * @param {typeof sap.ui.model.json.JSONModel} formatter 
 */
function (BaseController, JSONModel, MessageBox, formatter) {
        "use strict";

		return BaseController.extend("com.jabil.surveyform.controller.VendorSurvey", {
            formatter: formatter,
			onInit: function () {

           
                var oi18n_En= this.getOwnerComponent().getModel("i18n_en");
                this.getView().setModel(oi18n_En ,"oi18n_En");
                 this.getOwnerComponent().getModel("oVisibilityModel").getData()._defaultLan= sap.ui.getCore().getConfiguration().getLanguage();
                 this.getOwnerComponent().getModel("oVisibilityModel").refresh();
            //  this.getView().getModel("oVisibilityModel").setProperty("/_defaultLan", sap.ui.getCore().getConfiguration().getLanguage());

				// @ts-ignore
				this.getView().byId("surveyWizard").setRenderMode("Page");

				
				// @ts-ignore
				//  this.array = [];
				// @ts-ignore
                //  this.getView().setModel(this.array, "oAttachmentList");
               

			},
			fnCheckAuthority: function(oEvt){
                	var sCurrentStepId = oEvt.getParameter("id");
			sCurrentStepId = sCurrentStepId.split('-').pop();
if(sCurrentStepId == "basicInfo"){
        var oModel = this.getView().getModel("oDataModel");
      var  _isAuthorized= oModel.getData()["form"].authority,
          oBasicInfoStep = this.getView().byId("basicInfo");
          oBasicInfoStep.setValidated(_isAuthorized);

}
            },
        fnOperationServiceSel: function(oEvt){
                var that= this;
var listLen = this.getView().byId("operServList").getSelectedItems().length;
if(listLen > 3){
    	sap.m.MessageBox.alert((that.getView().getModel("i18n").getResourceBundle().getText("oprServAlertMsg")), {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
							});
}
            },
        fnManufaturingProdSel: function(oEvt){
                var that=this;
var listLen = this.getView().byId("manServList").getSelectedItems().length;
if(listLen > 3){
    sap.m.MessageBox.alert((that.getView().getModel("i18n").getResourceBundle().getText("manServAlertMsg")), {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
							});
}
            },
		
			// @ts-ignore
			fnOnFileUpload: function (oEvt) {
				var oFormData = new FormData(),
                    that = this,
                   fileUploadId = oEvt.oSource.sId.split("VendorSurvey--")[1],
					 fileUpload = this.getView().byId(fileUploadId),
					domRef = fileUpload.getFocusDomRef(),
					// @ts-ignore
					file = domRef.files[0];
				// this.fileName = file.name;
				// this.fileType = file.type;

				// @ts-ignore
				jQuery.sap.domById(fileUpload.getId() + "-fu").setAttribute("type", "file");
				// @ts-ignore
				oFormData.append("file", jQuery.sap.domById(fileUpload.getId() + "-fu").files[0]);
				oFormData.append("name", file.name);
				oFormData.append("folderName", "ven_02");
				oFormData.append("type", "application/octet-stream");
				var oAttachData = {

					"fileExt": file.name.split(".")[1],

					"fileName": file.name,
				};
            
               var _arrayTitle= this._fnGetUploaderId(fileUploadId);
                // if(fileUploadId == "fileUploader"){
                //     var _arrayTitle = "bPDArray";
                // } else if(fileUploadId == "fileUploader_OW"){
                //      var _arrayTitle = "ownerDArray";
                // }
                // else if(fileUploadId == "fileUploader_CO"){
                //      var _arrayTitle = "compDArray";
                // }
                // else if(fileUploadId == "fileUploader_BA"){
                //      var _arrayTitle = "bankDArray";
                // }
                // else if(fileUploadId == "fileUploader_SH"){
                //      var _arrayTitle = "shippingDArray";
                // }
                // else if(fileUploadId == "fileUploader_PR"){
                //      var _arrayTitle = "compProdDArray";
                // }
                // else if(fileUploadId == "fileUploader_CCO"){
                //      var _arrayTitle = "compContDArray";
                // }
                // else if(fileUploadId == "fileUploader_FI"){
                //      var _arrayTitle = "compFinDArray";
                // }
                // else if(fileUploadId == "fileUploader_CC"){
                //      var _arrayTitle = "compComplDArray";
                // }
                // else if(fileUploadId == "fileUploader_CY"){
                //      var _arrayTitle = "compSecuDArray";
                // }
				var sUrl = "/portal_services/document/upload";
				// @ts-ignore
				$.ajax({
					url: sUrl,
					data: oFormData,
					contentType: false,
					accept: '*/*',
					type: 'POST',
					processData: false,
					success: function (data) {
                        oAttachData.dmsDocumentId = data.dmsDocumentId;
                        oAttachData.dmsFolderId = data.dmsFolderId;
                        	// @ts-ignore
			//	that.array.push(oAttachData);
                // @ts-ignore
                 that.getView().getModel("oAttachmentList").getProperty("/0/"+ _arrayTitle).push(oAttachData);
                 that.getView().getModel("oAttachmentList").refresh(true);
               // that.getView().getModel("oAttachmentList").setData(that.array);
                        //that.getView().getModel("oAttachmentList").getData().push(data);
                      

					},
					error: function () {

					}
				});
			},
			// @ts-ignore
			fnOnCancelAttachment: function (oEvt) {
this.getView().getModel("oAttachmentList").refresh(true);
var that= this,  _arrayTitle = oEvt.oSource.oParent.oParent.oParent.oParent.mBindingInfos.items.path.split("/0/")[1];
				var fileName = oEvt.getSource().getParent().oParent.getItems()[0].mAggregations.items[1].getProperty("text");
				// @ts-ignore
				var dmsDocId = this.getView().getModel("oAttachmentList").getProperty("/0/"+ _arrayTitle).filter(function (docId) {
                        return docId.fileName == fileName })[0].dmsDocumentId;
                        // var _arrayTitle= this._fnGetUploaderId(fileUploadId);
                var	sUrl = "/portal_services/document/deleteByDmsDocumentId/" + dmsDocId;
                $.ajax({
					url: sUrl,
					contentType: false,
					accept: '*/*',
					type: 'DELETE',
					processData: false,
					success: function () {
                      var index=  that.getView().getModel("oAttachmentList").getProperty("/0/"+ _arrayTitle).findIndex(function(docId){return docId.fileName==fileName});
                        that.getView().getModel("oAttachmentList").getProperty("/0/"+ _arrayTitle).splice(index,1);
                          that.getView().getModel("oAttachmentList").refresh(true);
                    },
					error: function () {

					}
				});
			},

			fnOnDownlAttachment: function (oEvt) {
                 this.getView().getModel("oAttachmentList").refresh(true);
                var fileName = oEvt.getSource().getParent().oParent.getItems()[0].mAggregations.items[1].getProperty("text"),
                  _arrayTitle =oEvt.oSource.oParent.oParent.oParent.oParent.mBindingInfos.items.path.split("/0/")[1];
				// @ts-ignore
				var dmsDocId = this.getView().getModel("oAttachmentList").getProperty("/0/"+ _arrayTitle).filter(function (docId) {
                        return docId.fileName == fileName })[0].dmsDocumentId;
                         //var _arrayTitle= this._fnGetUploaderId(fileUploadId);
				var	sUrl = "/portal_services/document/download/" + dmsDocId;
				// @ts-ignore
				$.ajax({
					url: sUrl,
					//   contentType: false,
					//   accept:'*/*',
					//   localUri: "/Downloads",
					type: 'GET',
					xhrFields: {
						responseType: 'blob'
					},
					//   processData: false,
					success: function (data) {
						var a = document.createElement('a');
						var url = window.URL.createObjectURL(data);
						a.href = url;
						a.download = fileName;
						document.body.append(a);
						a.click();
						a.remove();
						window.URL.revokeObjectURL(url);

					},
					error: function () {

					}
				});

            },
            _fnGetUploaderId: function(fileUploadId){
                
                if(fileUploadId == "fileUploader"){
                    return "bPDArray";
                } else if(fileUploadId == "fileUploader_OW"){
                     return "ownerDArray";
                }
                else if(fileUploadId == "fileUploader_CO"){
                    return "compDArray";
                }
                else if(fileUploadId == "fileUploader_BA"){
                     return "bankDArray";
                }
                else if(fileUploadId == "fileUploader_SH"){
                     return "shippingDArray";
                }
                else if(fileUploadId == "fileUploader_PR"){
                   return "compProdDArray";
                }
                else if(fileUploadId == "fileUploader_CCO"){
                     return "compContDArray";
                }
                else if(fileUploadId == "fileUploader_FI"){
                     return "compFinDArray";
                }
                else if(fileUploadId == "fileUploader_CC"){
                     return "compComplDArray";
                }
                else if(fileUploadId == "fileUploader_CY"){
                     return "compSecuDArray";
                }
                return "";
            },
            fnHandleOwnshpType: function(oEvent){
                var type= oEvent.getParameters().value;
                if(type =="Other"){
                    oEvent.getParameters().value = "Other - Enter here";
                }
            },
			// @ts-ignore
			nextStep: function (event) {
				// @ts-ignore
				this.getView().byId("surveyWizard").nextStep();
			},
			// @ts-ignore
			previousStep: function (event) {
				// @ts-ignore
				this.getView().byId("surveyWizard").previousStep();
			},
			addOwnbyInd1: function () {
				// @ts-ignore
				this.idOwnerShipInfo1 = this.byId("idOwnerShipInfo1");
				// @ts-ignore
				var oLabel1 = new sap.m.Label({
					text: "First Name:"
				}).addStyleClass("sapUiTinyMarginEnd");
				var oInput1 = new sap.m.Input().addStyleClass("sapUiTinyMarginEnd").addStyleClass("inputStyle");
				// @ts-ignore
				var oLabel2 = new sap.m.Label({
					text: "Last Name:"
				}).addStyleClass("sapUiTinyMarginEnd");
				var oInput2 = new sap.m.Input().addStyleClass("sapUiTinyMarginEnd").addStyleClass("inputStyle");

				// @ts-ignore
				var _gLayout1 = new sap.m.VBox({

                    items: [oLabel1, oInput1],
                    layoutData: new sap.m.FlexItemData({growFactor: 1})
				}).addStyleClass("sapUiSmallMarginEnd").addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");
				// @ts-ignore
				var _gLayout2 = new sap.m.VBox({

                    items: [oLabel2, oInput2],
                     layoutData: new sap.m.FlexItemData({growFactor: 1})
				}).addStyleClass("sapUiSmallMarginEnd").addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");

				// @ts-ignore
				var delIcon = new sap.ui.core.Icon({
					src: "sap-icon://delete",
                    press: this._fnDeleteContainerlayoutOwner
                    
                }).addStyleClass("sapUiMediumMarginTop");
                var _gLayout3 = new sap.m.VBox({
                    items:[delIcon],
                     layoutData: new sap.m.FlexItemData({growFactor: 5})
                }).addStyleClass("sapUiSmallMarginEnd").addStyleClass("sapUiSizeCompact");
				// @ts-ignore
				var _flex1 = new sap.m.FlexBox({
                    wrap:"Wrap",
					alignItems: "Center",
					justifyContent: "Start",
					direction: "Row",
					items: [_gLayout1, _gLayout2, _gLayout3]
				});
				// @ts-ignore
				this.idOwnerShipInfo1.addContent(_flex1);

			},
			addOwnbyInd2: function () {
				// @ts-ignore
				this.idOwnerShipInfo2 = this.byId("idOwnerShipInfo2");
				// @ts-ignore
				var oLabel1 = new sap.m.Label({
					text: "First Name:"
				}).addStyleClass("sapUiTinyMarginEnd");
				var oInput1 = new sap.m.Input().addStyleClass("sapUiTinyMarginEnd").addStyleClass("inputStyle");
				// @ts-ignore
				var oLabel2 = new sap.m.Label({
					text: "Last Name:"
				}).addStyleClass("sapUiTinyMarginEnd");
				var oInput2 = new sap.m.Input().addStyleClass("sapUiTinyMarginEnd").addStyleClass("inputStyle");

				// @ts-ignore
				var _gLayout1 = new sap.m.VBox({

                    items: [oLabel1, oInput1],
                    layoutData: new sap.m.FlexItemData({growFactor: 1})
				}).addStyleClass("sapUiSmallMarginEnd").addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");
				// @ts-ignore
				var _gLayout2 = new sap.m.VBox({

                    items: [oLabel2, oInput2],
                    layoutData: new sap.m.FlexItemData({growFactor: 1})
				}).addStyleClass("sapUiSmallMarginEnd").addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");

				// @ts-ignore
				var delIcon = new sap.ui.core.Icon({
					src: "sap-icon://delete",
					press: this._fnDeleteContainerlayoutOwner
                }).addStyleClass("sapUiMediumMarginTop");
                var _gLayout3 = new sap.m.VBox({
                    items:[delIcon],
                     layoutData: new sap.m.FlexItemData({growFactor: 5})
                }).addStyleClass("sapUiSmallMarginEnd").addStyleClass("sapUiSizeCompact");
				// @ts-ignore
				var _flex1 = new sap.m.FlexBox({
                    wrap:"Wrap",
					alignItems: "Center",
					justifyContent: "Start",
					direction: "Row",
					items: [_gLayout1, _gLayout2, _gLayout3]
				});
				// @ts-ignore
				this.idOwnerShipInfo2.addContent(_flex1);

			},
			addTaxRegistration: function () {
				// @ts-ignore
				this.gridTaxRegDetails = this.byId("gridTaxRegDetails");
				// @ts-ignore
				var gLabel1 = new sap.m.Label({
					text: "{i18n>taxID}"
				});
				var gInput1 = new sap.m.Input().addStyleClass("inputStyle");
				// @ts-ignore
				var gLabel2 = new sap.m.Label({
					text: "{i18n>country}"
				});
				// @ts-ignore
				var gInput2 = new sap.m.ComboBox({
                    width: "100%",
                    placeholder:"{i18n>select}",
				}).addStyleClass("inputStyle");
				// @ts-ignore
				var gLabel3 = new sap.m.Label({
					text: "{i18n>type}"
				});
				// @ts-ignore
				var gInput3 = new sap.m.ComboBox({
                    width: "100%",
                    placeholder:"{i18n>select}",
				}).addStyleClass("inputStyle");
				// @ts-ignore
				var gLabel4 = new sap.m.Label({
					text: "{i18n>other}"
				});
				var gInput4 = new sap.m.Input().addStyleClass("inputStyle");

				// @ts-ignore
				var _gLayout1 = new sap.m.VBox({

					items: [gLabel1, gInput1]
				}).addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");
				// @ts-ignore
				var _gLayout2 = new sap.m.VBox({

					items: [gLabel2, gInput2]
				}).addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");
				// @ts-ignore
				var _gLayout3 = new sap.m.VBox({

					items: [gLabel3, gInput3]
				}).addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");
				// @ts-ignore
				var _gLayout4 = new sap.m.VBox({

					items: [gLabel4, gInput4]
				}).addStyleClass("sapUiSizeCompact").addStyleClass("fontStyle");
				// @ts-ignore
				var delIcon = new sap.ui.core.Icon({
					src: "sap-icon://delete",
					press: this._fnDeleteContainerlayout
				}).addStyleClass("sapUiMediumMarginTop");
				// @ts-ignore
				var _gridC = new sap.ui.layout.Grid({
					containerQuery: true,
					hSpacing: 0.1,
					vSpacing: 0.1,
					defaultSpan: "XL2 L2 M2 S12",
					content: [_gLayout1, _gLayout2, _gLayout3, _gLayout4, delIcon]
				}).addStyleClass("gridSpacing").addStyleClass("sapUiSizeCompact");
				// @ts-ignore
				this.gridTaxRegDetails.addContent(_gridC);

			},
			// @ts-ignore
			fnOnUploadComplete: function (oEvent) {
				// this.getView().getModel("oAttachmentList").setProperty("fileSize",oEvent.mParameters.item._oFileObject.size);
var a=oEvent;
			},
			_fnDeleteContainerlayout: function (oEvent) {
				var rowItemContainer = oEvent.getSource().getParent();
				rowItemContainer.destroy();
            },
            	_fnDeleteContainerlayoutOwner: function (oEvent) {
				var rowItemContainer = oEvent.getSource().getParent().getParent();
				rowItemContainer.destroy();
			},
			onBeforeRendering: function () {},

			onAfterRendering: function () {

			}
		});
	});