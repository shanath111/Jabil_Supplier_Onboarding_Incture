// @ts-nocheck
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/Wizard",
    'com/jabil/surveyform/formatter/formatter'
], /**
 * @param {typeof sap.ui.core.mvc.Controller} Controller 
 * @param {typeof sap.ui.model.json.JSONModel} JSONModel 
 * @param {typeof sap.m.Wizard} Wizard 
 */
function (Controller,JSONModel,Wizard,formatter)  {
	"use strict";
 Wizard.CONSTANTS["MAXIMUM_STEPS"] = 12;
	return Controller.extend("com.jabil.surveyform.controller.BaseController", {
     formatter: formatter,
        readAttachmentData: function(){
           
        },

        getRouter: function () {
            return sap.ui.core.UIComponent.getRouterFor(this);
        },
        

    });
});
		