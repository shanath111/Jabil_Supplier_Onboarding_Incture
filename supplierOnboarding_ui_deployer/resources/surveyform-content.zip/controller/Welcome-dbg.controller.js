sap.ui.define([
        "sap/ui/core/mvc/Controller",
        "com/jabil/surveyform/controller/BaseController"
	],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
	function (BaseController) {
		"use strict";

		return BaseController.extend("com.jabil.surveyform.controller.Welcome", {
			onInit: function () {
	     
				
            },
            fnOnLanguageSelect: function(oEvent) {
var _selLan = oEvent.getSource().getSelectedKey();
sap.ui.getCore().getConfiguration().setLanguage(_selLan);

            },
            onPressAccept: function(){
                var alreadyAccepted= true;
this.getOwnerComponent().getRouter().navTo("VendorSurvey");
            }
		});
	});
