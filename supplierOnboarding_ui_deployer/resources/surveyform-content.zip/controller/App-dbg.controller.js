sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "com/jabil/surveyform/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.jabil.surveyform.controller.App", {
		onInit: function () {

		}
	});
});